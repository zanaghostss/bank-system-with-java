public class Account {
    User user;
    private String shcart;
    private String password;
    private  int Balance;

    public Account(User user, String shcart, String password, int balance) {
        this.user = user;
        this.shcart = shcart;
        this.password = password;
        Balance = balance;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getShcart() {
        return shcart;
    }

    public void setShcart(String shcart) {
        this.shcart = shcart;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getBalance() {
        return Balance;
    }

    public void setBalance(int balance) {
        Balance = balance;
    }

    public void wariz(int m){this.Balance+=m;}
    public void bardasht(int m){this.Balance-=m;}

    @Override
    public String toString() {
        return "Account{" +
                "user=" + user +
                ", shcart='" + shcart + '\'' +
                ", password='" + password + '\'' +
                ", Balance=" + Balance +
                '}';
    }
}
