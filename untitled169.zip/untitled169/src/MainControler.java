import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class MainControler {
    @FXML
    TextField shcaertext;
    @FXML
    TextField passtext;
    @FXML
    Label mylable;

    private Stage stage;
    private FXMLLoader loader;
    private Parent root;
    private Scene scene;
    static String shcart;
    static String pass;
    static Account loged;

    public void login(ActionEvent event) throws IOException {
         shcart=shcaertext.getText();
         pass=passtext.getText();


        for (Account account: Co1.accounts){
            if(account.getShcart().equals(shcart)&&account.getPassword().equals(pass)){
                loged=account;
                mylable.setText("Login successfully");
                loader=new FXMLLoader(getClass().getResource("Log.fxml"));
                root=loader.load();
                scene=new Scene(root);

                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();






            }
            else {
                mylable.setText("Flase");
            }

        }


    }
    public void SignUp(ActionEvent event) throws IOException {
        loader=new FXMLLoader(getClass().getResource("Si.fxml"));
        root=loader.load();
        scene=new Scene(root);

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    public void info(ActionEvent event) throws IOException {
        loader=new FXMLLoader(getClass().getResource("Inf.fxml"));
        root=loader.load();
        scene=new Scene(root);

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();


    }



}
