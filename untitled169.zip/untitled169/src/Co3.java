import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class Co3 {

    private Parent root;
    private Scene scene;
    private Stage stage;

    @FXML
    Label namel;
    @FXML
    Label lastl;
    @FXML
    Label agel;
    @FXML
    Label shl;
    @FXML
    Label pasl;
    @FXML
    Label balancel;
    public void refresh(ActionEvent event){
        namel.setText(MainControler.loged.getUser().getName());
        lastl.setText(MainControler.loged.getUser().getLast());
        agel.setText(MainControler.loged.getUser().getAge());
        shl.setText(MainControler.loged.getShcart());
        pasl.setText(MainControler.loged.getPassword());
        balancel.setText(Integer.toString(MainControler.loged.getBalance()));
    }
    public void back(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("Lo.fxml"));
        root=loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();


    }
    public void transfer(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("Tra.fxml"));
        root=loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void edit(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("Edit.fxml"));
        root=loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();
    }




}
