import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class CInfo {
    private FXMLLoader loader;
    private Parent root;
    private Stage stage;
    private Scene scene;
    public void info(ActionEvent event) throws IOException {
        loader=new FXMLLoader(getClass().getResource("Lo.fxml"));
        root=loader.load();
        scene=new Scene(root);

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();


    }
}
