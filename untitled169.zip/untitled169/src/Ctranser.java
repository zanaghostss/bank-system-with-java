import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Ctranser {
    @FXML
    TextField wariztext;
    @FXML
    TextField bartext;
    @FXML
    Label wlable;
    @FXML
    Label Blable;
    @FXML
    TextField shtext;
    @FXML
    TextField amounttext;
    @FXML
    Label tlable;
    private Parent root;
    private Scene scene;
    private Stage stage;


    public void wariz(ActionEvent event){
        String amountText=wariztext.getText();
        int amount=Integer.parseInt(amountText);
        MainControler.loged.wariz(amount);
        wlable.setText("successfuly warized ");
    }
    public void bardasht(ActionEvent event){
        String amountT=bartext.getText();
        int amount=Integer.parseInt(amountT);
        MainControler.loged.bardasht(amount);
        Blable.setText("Sucessfuly bardasht");

    }
    public void transfer(ActionEvent event){
        String sh=shtext.getText();
        String amountt=amounttext.getText();
        int amount =Integer.parseInt(amountt);
        for (Account account:Co1.accounts){
            if(account.getShcart().equals(sh)){
                MainControler.loged.bardasht(amount);
                account.wariz(amount);
                tlable.setText("Money Transferd sucessfully");
                break;

            }
        }
    }
    public void back(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("Log.fxml"));
        root=loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();


    }


}
