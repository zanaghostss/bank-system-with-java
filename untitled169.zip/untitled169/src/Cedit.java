import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Cedit {
    @FXML
    TextField nametext;
    @FXML
    TextField lasttext;
    @FXML
    TextField agetext;
    @FXML
    TextField shtext;
    @FXML
    TextField pastext;
    @FXML
    TextField balancetext;
    @FXML
    Label namel;
    @FXML
    Label lastl;
    @FXML
    Label agel;
    @FXML
    Label shl;
    @FXML
    Label balancel;
    @FXML
    Label passl;
    private FXMLLoader loader;
    private Parent root;
    private Scene scene;
    private Stage stage;
    public void setname(ActionEvent event){
        String name=nametext.getText();
        MainControler.loged.user.setName(name);
        nametext.setText("");
        namel.setText("name changed");
    }
    public void setlast(ActionEvent event){
        String last=lasttext.getText();
        MainControler.loged.user.setLast(last);
        lasttext.setText("");
        lastl.setText("last changed");


    }
    public void setage(ActionEvent event){
        String age=agetext.getText();
        MainControler.loged.user.setAge(age);
        agetext.setText("");
        agel.setText("age changed");
    }
    public void setsh(ActionEvent event){
        String sh=shtext.getText();
        MainControler.loged.setShcart(sh);
        shtext.setText("");
        shl.setText("shcart changed");

    }
    public void setpass(ActionEvent event){
        String pass=pastext.getText();
        MainControler.loged.setPassword(pass);
        pastext.setText("");
        passl.setText("password changed");
    }
    public void setbalance(ActionEvent event){
        String amountt=balancetext.getText();
        int amount=Integer.parseInt(amountt);
        MainControler.loged.setBalance(amount);
        balancetext.setText("");
        passl.setText("Balance changed");

    }

    public void back(ActionEvent event) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("Log.fxml"));
        root=loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();


    }







}
