import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class Co1 {
    @FXML
    TextField nametext;
    @FXML
    TextField lasttext;
    @FXML
    TextField ageText;
    @FXML
    TextField shtext;
    @FXML
    TextField passtext;
    @FXML
    TextField balanceText;
    static ArrayList<Account>accounts=new ArrayList<>();
    private FXMLLoader loader;
    private Parent root;
    private Scene scene;
    private Stage stage;


    public void save(ActionEvent event){
        String name=nametext.getText();
        String last=lasttext.getText();
        String age=ageText.getText();

        User user=new User(name,last,age);

        String shcart=shtext.getText();
        String pass=passtext.getText();
        int balance=Integer.parseInt(balanceText.getText());

        Account account=new Account(user,shcart,pass,balance);
        accounts.add(account);

        nametext.setText("");
        lasttext.setText("");
        ageText.setText("");
        shtext.setText("");
        passtext.setText("");
        balanceText.setText("");



    }
    public void next(ActionEvent event) throws IOException {
        loader=new FXMLLoader(getClass().getResource("Lo.fxml"));
        root=loader.load();

        scene=new Scene(root);
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();




    }



}
